import React from 'react';
import TaskManager from '@/components/TaskManager';

const Index: React.FC = () => {
  return <TaskManager />;
};

export default Index;
